package com.community.xanadu.components.checker;

public interface Checker<T> {
	String validate(T comp);
}
